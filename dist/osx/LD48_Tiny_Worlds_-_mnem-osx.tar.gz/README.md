## Ludum Dare 23: Tiny World in 48 hours

mnem's entry for Ludum Dare 23, 48 hour compo

This is more a minimal plaything than a game really - I was lacking
inspiration this weekend :/

You are Gravity, new on the job, and you've been given a trial period by
God, before he decides to keep you on full time. He's been handcrafting
worlds all over the shop, but He's bored and wants a holiday.

Using your Audacious Powers of Coalescence, you have to form as many
planets as you can from the space dust the Boss has left floating
around. Be careful! Don't form the planets too close to each other
in case they collide. You wouldn't want all those innocent
deaths on your conscience.

To activate your APoC, simply press the mouse button, hold it, and drag
your gravity point around. When enough bits of dust are close together
you will pop a new planet into existence.

Q or ESC quits.
