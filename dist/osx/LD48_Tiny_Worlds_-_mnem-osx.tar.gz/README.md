## Ludum Dare 23: Tiny World in 48 hours

mnem's entry for Ludum Dare 23, 48 hour compo

The aim of this is to use your gravitational prowess to coalesce all the
space dust into planets. Watch out for planets colliding! We want a safe,
happy solar system, not one with millions of deaths!

Mouse around and keep the button held to increase gravity in an area.

q quits.
